package com.swufe.javaee.beerV1.model;

public class String {
}
